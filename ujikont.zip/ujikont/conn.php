<?php  
	// nama database (ujikont)
	$conn = new mysqli("localhost", "root", "", "ujikont");
?>